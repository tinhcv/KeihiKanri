package ki1nhom2.btl.qlct;

import android.content.Context;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MonthlyStatisticAdapter extends RecyclerView.Adapter {

    private List monthlyStatisticInfo;
    private Context context;

    public MonthlyStatisticAdapter(List monthlyStatisticInfo, Context context) {
        this.monthlyStatisticInfo = monthlyStatisticInfo;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View monthlyStatisticInfo = inflater.inflate(R.layout.monthly_statistic_node, parent, false);

        return new ViewHolder(monthlyStatisticInfo);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private View itemView;
        public TextView monthName;
        public TextView income;
        public TextView outcome;
        public ImageButton dropdown;

        public ViewHolder(View itemView) {
            super(itemView);
            this.itemView = itemView;
            monthName = itemView.findViewById(R.id.monthName);
            income = itemView.findViewById(R.id.income);
            outcome = itemView.findViewById(R.id.outcome);
            dropdown = itemView.findViewById(R.id.dropdown);

            dropdown.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(),
                            monthName.getText() + " - " + income.getText() + " - " + outcome.getText(),
                            Toast.LENGTH_LONG).show();
                }
            });
        }
    }
}
