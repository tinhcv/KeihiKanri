package ki1nhom2.btl.qlct

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private val balance = 100000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView = findViewById<TextView>(R.id.balanceNumber)
        textView.text = toMoneyFormat(balance)
    }

    private fun toMoneyFormat(money : Int) : String {
        if(money < 1000) return money.toString()

        var input : Int = money
        var output = ""

        var counter = 0
        while (input > 0) {
            if(counter % 3 == 0 && counter != 0) output = ",$output"
            output = (input % 10).toString() + output
            input /= 10
            counter++
        }

        return output
    }
}