package ki1nhom2.btl.qlct

import java.util.HashMap

class MonthlyStatisticStructure(
    var monthIndex: String,
    var totalConsumption: Long,
    var consumptionList: List<HashMap<String, Long>>
)